document.querySelector('.banner .btn').addEventListener('click', function() {
    alert('Buscando feiras próximas!');
  });
  